<?php
session_start();
if (!isset($_SESSION['username'])) {
   header("Location: login.html");
   exit();
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $product_id = $_POST['product_id'];


   $conn = new mysqli("localhost", "root", "Prost123", "inventory_db");


   if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
   }


   $stmt = $conn->prepare("DELETE FROM Product WHERE product_id = ?");
   $stmt->bind_param("i", $product_id);
   $stmt->execute();
   $stmt->close();
   $conn->close();


   echo "Product deleted successfully.";
}
?>


