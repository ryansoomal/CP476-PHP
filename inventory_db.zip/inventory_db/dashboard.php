<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "Prost123";
$dbname = "inventory_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Join Product and Supplier tables to get the required inventory data
$sql = "SELECT Product.product_id, Product.product_name, Product.units_in_stock, Product.unit_price, Supplier.supplier_name 
        FROM Product 
        INNER JOIN Supplier ON Product.supplier_id = Supplier.supplier_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    $(document).ready(function() {
        // Delete product
        $(document).on('click', '.delete-button', function() {
            var productId = $(this).data('id');
            $.ajax({
                url: 'delete_product.php',
                type: 'POST',
                data: { product_id: productId },
                success: function(response) {
                    // Remove the product row from the table
                    $('#product-' + productId).remove();
                },
                error: function() {
                    alert('Error deleting product.');
                }
            });
        });

                // Update product
        $(document).on('submit', '.update-form', function(event) {
            event.preventDefault();
            var form = $(this);
            $.ajax({
                url: 'update_product.php',
                type: 'POST',
                data: form.serialize(),
                success: function(response) {
                    // Optionally reload the page or update the specific row
                    location.reload();
                },
                error: function() {
                    alert('Error updating product.');
                }
            });
        });
    });
    </script>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?></h1>
    <h2>Inventory</h2>
    <table border="1" id="inventory-table">
        <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Supplier Name</th>
            <th>Actions</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr id='product-{$row['product_id']}'>
                        <td>{$row['product_id']}</td>
                        <td>{$row['product_name']}</td>
                        <td>{$row['units_in_stock']}</td>
                        <td>{$row['unit_price']}</td>
                        <td>{$row['supplier_name']}</td>
                        <td>
                            <form class='update-form' method='post' style='display:inline;'>
                                <input type='hidden' name='product_id' value='{$row['product_id']}'>
                                <input type='number' name='units_in_stock' value='{$row['units_in_stock']}' required>
                                <button type='submit'>Update</button>
                            </form>
                            <button class='delete-button' data-id='{$row['product_id']}'>Delete</button>
                        </td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No products found</td></tr>";
        }
        ?>
    </table>

    </body>
</html>

<?php
$conn->close();
?>