<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];
    $units_in_stock = $_POST['units_in_stock'];

    $conn = new mysqli("localhost", "root", "Prost123", "inventory_db");

    if ($conn->connect_error) {
        die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
    }

    $stmt = $conn->prepare("UPDATE Product SET units_in_stock = ? WHERE product_id = ?");
    $stmt->bind_param("ii", $units_in_stock, $product_id);

    if($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Product updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error updating product: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}
?>
